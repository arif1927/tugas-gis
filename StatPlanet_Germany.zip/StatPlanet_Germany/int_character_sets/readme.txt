
To use additional character sets for StatPlanet Plus, please follow these steps:

1. copy the file 'content.swf' in this directory into the directory 'web'.
(replacing the existing file)

2. remove the file "settings.csv" in the main directory and also in the
directory 'web'.

3. in the StatPlanet Data Editor, go to the sheet "Settings".
Under Startup options - Data format, select: TXT (tab-separated values).

--------

The file content.swf contains additional character sets,
and therefore the file-size is larger than the original content.swf.

The additional character sets are:

Arabic
Armenian
Chinese (All character sets)
Cyrillic (for Russian, Serbo-Croatian and Tajik, amongst others)
Devanagari (for Hindi, Marathi and Nepali, amongst others)
Hebrew
Japanese (All character sets)
Korean (All character sets)
Thai
Greek
Latin I, Latin Extended A, Latin Extended B, Latin Extended Add'l
