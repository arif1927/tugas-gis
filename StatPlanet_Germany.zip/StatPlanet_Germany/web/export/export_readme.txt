For export to work, your web server needs to be configured to work with PHP or ASP files.

By default StatPlanet will use the PHP version. If your web server is configured to use ASP files,
you would need to change the following setting in the StatPlanet Data Editor, sheet 'settings':

- Setting: "EXPLANG", in the section 'Export options'
- Value: change from 'php' to 'asp'