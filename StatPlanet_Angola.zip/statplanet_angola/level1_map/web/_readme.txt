
The 'For testing purposes only' message will disappear once the software has been uploaded
to a licensed web-domain. The following domains are automatically licensed:

"tl", "st", "ao", "af", "am", "bd", "bj", "bw", "bi", "bf", "cd", "cf", "ci", "cg", 
"cm", "cv", "er", "et", "gm", "gn", "gw", "ht", "lr", "ke", "kg", "kp", "kh", "km", 
"ls", "mr", "mg", "mu", "ml", "mw", "mz", "mm", "na", "np", "ne", "ng", "rw", "sl", 
"so", "sn", "sc", "ss", "sd", "sz", "td", "tg", "tj", "tz", "ug", "za", "zm", "zw"

INTERNET EXPLORER:

If you get an Internet Explorer security warning on opening StatPlanet.html, use
StatPlanet_IE_offline.html instead. The security warning should disappear in Internet Explorer
once it is online.
